package common;

public class Common {

	public static String common_test() {
		return "I am common out";
	}

}
