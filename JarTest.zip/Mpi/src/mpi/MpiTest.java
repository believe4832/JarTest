package mpi;

import common.Common;

public class MpiTest {

	public String getCommonMsg() {
		return Common.common_test();
	}
}
