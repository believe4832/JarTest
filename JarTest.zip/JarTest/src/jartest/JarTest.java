package jartest;

import common.Common;

public class JarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Who are you?");
		System.out.println("Mpi����common");
		System.out.println(Common.common_test());
		System.out.println("main����common");
		System.out.println(Common.common_test());
	}
}
